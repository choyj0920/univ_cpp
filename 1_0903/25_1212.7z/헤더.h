#pragma once
#include <iostream>
#include <vector>
using namespace std;

#include"Item.h"
#include"CannedDrinks.h"
#include "Coffee.h"
#include "VendingMachine.h"
#include "VendingManager.h"

