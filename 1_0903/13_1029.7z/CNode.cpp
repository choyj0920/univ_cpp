#include "CNode.h"

CNode::CNode()
{
}

CNode::~CNode()
{
}
