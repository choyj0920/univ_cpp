﻿// 13_1029.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//
#include <iostream>
using namespace std;
#include "CLinkedList.h"
int main()
{
	CLinkedList cl;
	cl.insertsort(70);
	cl.insertsort(20);
	cl.insertsort(20);
	cl.insertsort(80);
	cl.insertsort(20);
	cl.insertsort(30);
	cl.showList();
}

